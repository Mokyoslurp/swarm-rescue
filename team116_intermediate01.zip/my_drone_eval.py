from swarm_rescue.solutions.my_solution.my_drone_solution import MyDroneSolution


class MyDroneEval(MyDroneSolution):
    """
    Evaluation drone class that inherits from MyDroneRandom.

    This class can be extended to implement custom evaluation logic.
    """

    pass
